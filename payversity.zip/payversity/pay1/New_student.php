
<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Payversity</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="js/sem.js">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<div class="sidebar">
    <div class="logo-details">
      <img src="image/logo_white.png" class="dashboard_logo" alt="">
      
    </div>
      <ul class="nav-links">
        <li  onclick="slide2()">
          <a href="#" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li onclick="slide1()">
          <a href="New_student.php" >
            <i class='bx bx-list-ul' ></i>
            <!-- <i class='bx bx-box' ></i> -->
            <span class="links_name">Enter Student Data</span>
          </a>
        </li>
        <li onclick="slide3()">
          <a href="enrollment_search.php" >
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Enrollment Search</span>
          </a>
        </li>
        <li onclick="slide4()">
          <a href="detail_search.php">
            <i class='bx bx-list-ul' ></i>
            <!-- <i class='bx bx-pie-chart-alt-2' ></i> -->
            <span class="links_name">Detailed Search</span>
          </a>
        </li>
       
        <li>
          <a href="#">
            <i class='bx bx-cog' ></i>
            <span class="links_name">Settings</span>
          </a>
        </li>
        <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section" id="data2"> 
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
     
      <div class="profile-details">
        <img src="image/profile.jpg" alt="">
        <span class="admin_name">Prof. Prashant Sahatiya</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>
</div>
</div>
<?php
include("db.php");
// Check connection
if(isset($_POST['submit'])){
    $enrollment = $_POST['enrollment'];
    $name = $_POST['stud_name'];
    $course = $_POST['course'];

    $department = $_POST['department'];
    $semester = $_POST['semester'];
    $payment_status = $_POST['payment_status'];
    $divison = $_POST['divison'];
    $sql = "INSERT INTO payment (enrollment, stud_name, course,department, semester, payment_status, divison)
VALUES('$enrollment','$name','$course','$department','$semester','$payment_status','$divison')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}



mysqli_close($conn);
?>
 <div class="home-content new_student_box detail_search">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
<form action="" method="POST" class="new_student_form">
<label  for="enrollment"> Enrollment: </label><input  class="form-styling student_register_single" type="text" name="enrollment">

<label  for="enrollment" class="new_stu_mar">Name:</label><input class="form-styling student_register_single"  type="text" name="stud_name"><br>
<label  for="enrollment"> Course:</label><input class="form-styling student_register_single"  type="text" name="course">
<label  for="enrollment" class="new_stu_mar">Department:</label><select style="font-size: 16px;" class="department student_register_single" name="department" id="department">
                        <option style="font-size: 15px;">Choose...</option>
                        <option value="Information Technology" style="font-size: 15px;">IT</option>
                        <option value="CSE" style="font-size: 15px;">CSE</option>
                        <option value="MECHANICAL" style="font-size: 15px;">MECHANICAL</option>
                        <option value="ELECTRICAL" style="font-size: 15px;">ELECTRICAL</option>
                        <option value="MCA" style="font-size: 15px;">MCA</option>
                        <option value="MBA" style="font-size: 15px;">MBA</option>
                        <option value="B.Sc" style="font-size: 15px;">B.Sc</option>
                    </select><br>
<label  for="enrollment"> Semester:</label><select style="font-size: 16px;" class="semester student_register_single" name="semester" id="sem">
                        <option>Choose...</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                    </select>
<label  for="enrollment" class="new_stu_mar">Payment_status:</label> <input class="" type="radio" name="payment_status" value="Pending"><span>Pending</span>
                <input type="radio"  name="payment_status" value="Succesfull"><span class="student_register_single">Successfull</span><br>

                <div class="center">
<label  for="enrollment" class="center"> division:</label><select style="font-size: 16px;" class="divison student_register_single" name="divison">
                        <option style="font-size: 15px;">Choose...</option>
                        <option value="A" style="font-size: 15px;">A</option>
                        <option value="B" style="font-size: 15px;">B</option>
                        <option value="C" style="font-size: 15px;">C</option>
                        <option value="D" style="font-size: 15px;">D</option>
                    </select>
                    </div>
                    <br>
                    <div class="center">
  <input class="enroll-button student_register_single" type="submit"  name="submit">
 
</div>
</form>

</div>
</div>
</div>
</div>


</body>
</html>