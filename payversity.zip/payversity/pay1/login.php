<?php 
// define('Secured',TRUE);
include('DB-Connection.php');
session_start();

?>
<?php

if(isset($_POST['Login'])){




    $username = $_POST['Username'];
    $pass = $_POST['password'];
    // $pass = md5($_POST['password']);
// use md5 password in database
    
    

    if(empty($_POST['userType'])){
        echo "Enter Your Required Details";
    } else {
        $user_data = $_POST['userType'];   
        if($user_data == '3'){
            $email_search = " select * from student_data where `User_id` = '$username' and `Password` = '$pass' ";
            $query = mysqli_query($conn, $email_search);

            // fetch the data-table whether the userid is same as the user id in the current page and if logged out it will give you login again or not
            $fetch=mysqli_fetch_assoc($query);
            $_SESSION['User_id']=$fetch['User_id'];
           
           if($query->num_rows > 0){
        
               echo "Success";
            
               header('location: student.php');
           } else {
               
               echo "Please check User password ";
           }
        }
        else if($user_data == '1'){
            $email_search = " select * from faculty_data where `User_id` = '$username' and `Password` = '$pass' ";
            $query = mysqli_query($conn, $email_search);


            $fetch=mysqli_fetch_assoc($query);
            $_SESSION['User_id']=$fetch['User_id'];
           
           if($query->num_rows > 0){
        
               echo "Success";
               header('location: dashboard.php');
           } else {
               
               echo "Please check User password ";
           }   
        }
        else if($user_data == '2'){
            $email_search = " select * from parent_data where `User_id` = '$username' and `Password` = '$pass' ";
            $query = mysqli_query($conn, $email_search);


            $fetch=mysqli_fetch_assoc($query);
            $_SESSION['User_id']=$fetch['User_id'];
           
           if($query->num_rows > 0){
        
               echo "Success";
               header('location: parent.php');
           } else {
               
               echo "Please check User password ";
           }   
        }
    }



     

   

   
   
   
    
}



?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>login page</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/style.css">

        <!-- Boostrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    </head>
    <body class="">
        <div class="container ">
            <div class="row justify-content-center login-banner">
                <div class="col-lg-5 bg-grey mt-9 px-0"> <!--main part-->
                <div class="login-main">
                <img src="image/logo_new.png" alt="" class="login-logo">
                </div>
                    <h3 class="text-center p-1 rounded-top login-main2">Login Panel</h3> 
                     <form action="#" method="POST" class="p-4">
                     <label for="user">Username</label>
                         <div class="form-group bg-red-lg">
                            
                             <input type="text" name="Username" class="form-control form-control-lg" placeholder="Username" >
                         </div>
                         <label for="user">Password</label>
                         <div class="form-group bg-red-lg">
                              
                             <input type="password" name="password" class="form-control form-control-lg " placeholder="Password" >
                         </div>

                         <div class="form-group">
                             <label class="mt-3" for="userType">I'm a : </label>
                             <input type="radio" name="userType" value="3" class="form-check-input mt-4 form-check-label" ><span class="radio-size">&nbsp;Student  &nbsp;  &nbsp;|</span>
                             <input type="radio" name="userType" value="1" class="form-check-input mt-4 form-check-label" ><span class="radio-size">&nbsp;  Faculty  &nbsp;  &nbsp;|</span>
                             <input type="radio" name="userType" value="2" class="form-check-input mt-4 form-check-label" ><span class="radio-size">&nbsp;  Parent  &nbsp; </span>
                         </div>

                        <!--
                         <div class="form-group">
                             <input type="submit" name="login" class="btn btn-danger btn-block mt-3 p-2"/>       
                         </div>
                         -->
                         <div class="form-group ">
                            <input type="submit" name="Login" value="Login" class=" login-page btn btn-danger btn-block mt-3 p-2"/>
                         </div>
                         

                     </form>
                </div>
            </div>
        </div>
    </body>
</html>