-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2021 at 08:09 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payversity1`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `enrollment` varchar(50) NOT NULL,
  `stud_name` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `department` varchar(50) NOT NULL,
  `divison` varchar(15) NOT NULL,
  `semester` int(10) NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `amount` int(50) NOT NULL,
  `payment_status` text NOT NULL,
  `time` datetime(6) NOT NULL,
  `payment_id` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `pcont` text NOT NULL,
  `pemail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`enrollment`, `stud_name`, `course`, `department`, `divison`, `semester`, `start_date`, `due_date`, `amount`, `payment_status`, `time`, `payment_id`, `pname`, `pcont`, `pemail`) VALUES
('180303108069', 'Sandhya Nimbark', '01-PIET-1', 'Information Technology', 'A', 7, '2021-05-15', '2021-06-30', 0, '', '0000-00-00 00:00:00.000000', '', '', '0', ''),
('180303108105', 'Uttam Pragada', '01-PIET-1', 'Information Technology', 'A', 7, '2021-05-15', '2021-06-30', 0, '', '0000-00-00 00:00:00.000000', '', '', '0', ''),
('180303108113', 'Parul Rathva', '01-PIET-1', 'Information Technology', 'A', 7, '2021-05-15', '2021-06-30', 45000, 'succesfull', '2021-06-21 08:07:46.000000', 'pay_HPnq1zCd3fnHGA', 'parul', '1234567890', 'p@gmail.com'),
('180303108115', 'Aesha Ray', '01-PIET-1', 'Information Technology', 'B', 7, '2021-05-15', '2021-06-30', 0, '', '0000-00-00 00:00:00.000000', '', '', '0', ''),
('180303108123', 'Riya Shah', '01-PIET-1', 'Information Technology', 'B', 7, '2021-05-15', '2021-06-30', 0, '', '0000-00-00 00:00:00.000000', '', '', '0', ''),
('180303108124', 'Sapan Shah', '01-PIET-1', 'Information Technology', 'B', 7, '2021-05-15', '2021-06-30', 90000, 'succesfull', '2021-06-21 08:05:42.000000', 'pay_HPnnsWhQhgCPD5', 'sa', '54546545', 'dhjfdkh'),
('180303108144', 'Meet Vaghasiya', '01-PIET-1', 'Information Technology', 'C', 7, '2021-05-15', '2021-06-30', 0, '', '0000-00-00 00:00:00.000000', '', '', '0', ''),
('180303108145', 'Yashpalsinh Vaghela', '01-PIET-1', 'Information Technology', 'C', 7, '2021-05-15', '2021-06-30', 0, '', '0000-00-00 00:00:00.000000', '', '', '0', ''),
('180303108156', 'Keval Virani', '01-PIET-1', 'Information Technology', 'C', 7, '2021-05-15', '2021-06-30', 0, '', '0000-00-00 00:00:00.000000', '', '', '0', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`enrollment`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
