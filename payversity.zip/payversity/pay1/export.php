<?php
include("db.php");
// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 
 
// Excel file name for download 
$fileName = "Fees-detail_" . date('d-m-Y') . ".xls"; 
 
// Column names 
$fields = array('enrollment', 'stud_name', 'course', 'department', 'divison', 'semester', 'start_date', 'due_date','amount','payment_status','time','payment_id','pname','pcont','pemail'); 
 
// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 
 
// Fetch records from database 
$query = $conn->query("SELECT * FROM payment"); 
if($query->num_rows > 0){ 
    // Output each row of the data 
    while($row = $query->fetch_assoc()){ 
        // $status = ($row['payment_status'] == 1)?'Pending':'succesfull'; 
        
        $lineData = array($row['enrollment'], $row['stud_name'], $row['course'], $row['department'], $row['divison'], $row['semester'], $row['start_date'],$row['due_date'],$row['amount'],$row['payment_status'],$row['time'],$row['payment_id'],$row['pname'],$row['pcont'],$row['pemail']); 
        array_walk($lineData, 'filterData'); 
        $excelData .= implode("\t", array_values($lineData)) . "\n"; 
    } 
}else{ 
    $excelData .= 'No records found...'. "\n"; 
} 
 
// Headers for download 
header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment; filename=\"$fileName\"");
 
// Render excel data 
echo $excelData; 
 
exit;
?>