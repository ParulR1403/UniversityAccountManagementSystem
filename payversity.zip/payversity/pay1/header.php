
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>PayVersity</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='css/style.css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script src='script.js'></script>
    <script src='JS/main.js'></script>
   
</head>
 
    <nav id="myheader">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="logo">
                       <a href="index.php"><img src="image/logo_new.png" alt=""></a> 
                    </div>
                </div>
                    
                <div class="col-lg-8">
                    <ul class="navbar">
                       <li><a href="about.php">Universities</a></li>
                       <li> <a href="">Our Team<i class="arrow down dropdown"></i></a>
                            <!-- <ul>
                            <li><a href="founder.php">Our Founders</a></li>
                            <li><a href="">Our Commitee</a></li>
                            </ul> -->
                       </li>
                       <li> <a href="">FAQs</a><i class="arrow down dropdown"></i>
                       <!-- <ul class="company-dropdown">
                            <li><a href="work.php">How it Works</a></li>
                            <li><a href="benefits.php">Benefits of Investors</a></li>
                            <li><a href="faqs.php">FAQs</a></li>
                            </ul> -->
                            </li>
                       <li><a href="contact.php">Contact Us</a></li>
                      
                    </ul>  
                    
                </div>
                <div class="col-lg-1">
                <a href="login.php"><button class="login">Login</button></a>
                <!-- <a href="logout.php"><button class="login">Logout</button></a> -->
                </div>
        
        
                <div id="menu">
        <div class="line-menu" id="line1"></div>
        <div class="line-menu" id="line2"></div>
        <div class="line-menu" id="line3"></div>
        </div>



            </div>
        </div>
    </nav>
    

