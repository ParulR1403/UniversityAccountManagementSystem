<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Payversity</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='css/style.css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

   


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src='script.js'></script>
   
</head>
<body>
    <header>
        <!-- <div id="myheader" class="header-main container-fluid"> 
            <div class="d-flex">
                <div class="col-lg-5">
                    <div class="logo">
                        <img src="image/1111111.png" alt="">
                    </div>
                </div>
                <div class="col-lg-7">
                        <ul class="nav navbar-nav">
                       <li><a href="#">About Us</a></li>
                       <li><a href="#">Our Founders</a></li>
                       <li><a href="#">How It Works</a></li>
                       <li><a href="#">Contact Us</a></li>
                       <li><a href="#"><img src="image/loupe (1).png" alt=""></a></li>
                    </ul>  
                </div>
            </div>
          
        </div>  -->
        <?php
        include('header.php');
        ?>




<div id="myCarousel" class="carousel slide " data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>

    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
      <div class="main1 d-flex"> 
            <div class="col-lg-5 main11">
                 <h1>University Fees Payment Is Now So Easy.</h1>
                 <!-- <P>Lorem Ipsum Is Simply Dummy Text Of</P> -->
                 <button class="rd">Pay Here</button>
                 <br>
                 <!-- <img src="image/Component 9 – 1.png" alt=""> -->
                 <!-- <img src="image/Component 10 – 1.png" alt=""> -->
            </div>
            <div class="col-lg-7">
              
                   <img src="image/img2.png" class="img2" alt="">
                
            </div>
         </div> 




      </div>

      <div class="item">
      <div class="main1 d-flex"> 
            <div class="col-lg-5 main11">
                 <h1>Fully Secured Payment Options Available.</h1>
                 <!-- <P>Lorem Ipsum Is Simply Dummy Text Of</P> -->
                 <button class="rd">Pay Here</button>
                 <br>
                 <!-- <img src="image/Component 9 – 1.png" alt=""> -->
                 <!-- <img src="image/Component 10 – 1.png" alt=""> -->
            </div>
            <div class="col-lg-7">
              
                   <img src="image/img3.png" class="img3" alt="">
                
            </div>
         </div> 




      </div>
    
      <!-- <div class="item">
      <div class="main1 d-flex"> 
            <div class="col-lg-5 main11">
                 <h1>LOREM IPSUM IS SIMPLY<BR>TEXT OF THE PRINTING</h1>
                 <P>Lorem Ipsum Is Simply Dummy Text Of</P>
                 <button class="rd">Read More</button>
                 <br> -->
                 <!-- <img src="image/Component 9 – 1.png" alt=""> -->
                 <!-- <img src="image/Component 10 – 1.png" alt=""> -->
            <!-- </div>
            <div class="col-lg-7">
              
                   <img src="image/payment.png" class="img2" alt="">
                
            </div>
         </div> 

</div>

         <div class="item">
      <div class="main1 d-flex"> 
            <div class="col-lg-5 main11">
                 <h1>LOREM IPSUM IS SIMPLY<BR>TEXT OF THE PRINTING</h1>
                 <P>Lorem Ipsum Is Simply Dummy Text Of</P>
                 <button class="rd">Read More</button>
                 <br> -->
                 <!-- <img src="image/Component 9 – 1.png" alt=""> -->
                 <!-- <img src="image/Component 10 – 1.png" alt=""> -->
            <!-- </div>
            <div class="col-lg-7">
              
                   <img src="image/payment.png" class="img2" alt="">
                
            </div>
         </div>  -->

<!-- </div> -->


      </div>
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
    </div>



    <div class="container">  
			<div class="row justify-content-center mb-3  mx-0">
				<div class="col-xl-11 col-11">
					<h2 class="h3  text-semibold">Select Your Fees</h2>
					<hr class="title-hr ">
				</div>
			</div>
			<div class="row justify-content-center mb-3  mx-0">
				<div class="col-xl-11 col-11">
					<div class="row justify-content-center">
						<div class="col-md-6">
							<div class="card content-pay">
								<h5 class="card-header  text-bold">Indian Students</h5>
 
<div class="card-body px-3 pt-2 pb-2 border-top-2 border-bottom-2" style="border-top: 1px solid #dee2e6;">
	<p class="d-inline pt-2 pb-2 border-top-0 border-bottom-0">
		<sapn class="">Academic Fees (For Existing Students)
			<sapn class="float-right"><a href="student.php" target="_blank" class="btn btn-sm btn-red">Pay Now</a>
			</sapn></sapn></p>
		</div>
		
		
		
		 
<div class="card-body px-3 pt-2 pb-2 border-top-2 border-bottom-2" style="border-top: 1px solid #dee2e6;">
	<p class="d-inline pt-2 pb-2 border-top-0 border-bottom-0">
		<sapn class="">New Registrations (Hostel/Academic Fees)
			<sapn class="float-right"><a href="student.php" target="_blank" class="btn btn-sm btn-red">Pay Now</a>
			</sapn></sapn></p>
		</div>
		
		
		
		 
<div class="card-body px-3 pt-2 pb-2 border-top-2 border-bottom-2" style="border-top: 1px solid #dee2e6;">
	<p class="d-inline pt-2 pb-2 border-top-0 border-bottom-0">
		<sapn class="">Payment of Fees Other than Academic/Hostel Fees
			<sapn class="float-right"><a href="student.php" target="_blank" class="btn btn-sm btn-red">Pay Now</a>
			</sapn></sapn></p>
		</div>
		
		
		
		 
<div class="card-body px-3 pt-2 pb-2 border-top-2 border-bottom-2" style="border-top: 1px solid #dee2e6;">
	<p class="d-inline pt-2 pb-2 border-top-0 border-bottom-0">
		<sapn class="">Academic/Hostel Fees - For South Indian Students
			<sapn class="float-right"><a href="student.php" target="_blank" class="btn btn-sm btn-red">Pay Now</a>
			</sapn></sapn></p>
		</div>
		
		
		
		

							</div>
						</div>

						<div class="col-md-6">
							<div class="card content-pay">
								<h5 class="card-header  text-bold">International Students</h5>
 
<div class="card-body px-3 pt-2 pb-2 border-top-2 border-bottom-2" style="border-top: 1px solid #dee2e6;">
	<p class="d-inline pt-2 pb-2 border-top-0 border-bottom-0">
		<sapn class="">Academic/Hostel Fees (USD $) - For Existing Students
			<sapn class="float-right"><a href="student.php" target="_blank" class="btn btn-sm btn-red">Pay Now</a>
			</sapn></sapn></p>
		</div>
		
		
		
		 
<div class="card-body px-3 pt-2 pb-2 border-top-2 border-bottom-2" style="border-top: 1px solid #dee2e6;">
	<p class="d-inline pt-2 pb-2 border-top-0 border-bottom-0">
		<sapn class="">Academic/Hostel Fees (INR) - For Existing Students
			<sapn class="float-right"><a href="student.php" target="_blank" class="btn btn-sm btn-red">Pay Now</a>
			</sapn></sapn></p>
		</div>
		
		
		
		 
<div class="card-body px-3 pt-2 pb-2 border-top-2 border-bottom-2" style="border-top: 1px solid #dee2e6;">
	<p class="d-inline pt-2 pb-2 border-top-0 border-bottom-0">
		<sapn class="">New Admissions (Hostel/Academic Fees)
			<sapn class="float-right"><a href="student.php" target="_blank" class="btn btn-sm btn-red">Pay Now</a>
			</sapn></sapn></p>
		</div>
		
		
		
		 
<div class="card-body px-3 pt-2 pb-2 border-top-2 border-bottom-2" style="border-top: 1px solid #dee2e6;">
	<p class="d-inline pt-2 pb-2 border-top-0 border-bottom-0">
		<sapn class="">Fee Payment For Nepal &amp; Bhutan Students
			<sapn class="float-right"><a href="student.php" target="_blank" class="btn btn-sm btn-red">Pay Now</a>
			</sapn></sapn></p>
		</div>
		
		
		
		
							</div>
						</div>
					</div>
				</div>                        
			</div>              
		</div>


<section class="main2 container">
<div>
   <h1>Why Payversity?</h1> 
   <hr>
</div>
<div>
<p> Payversity Gives you Secured University Fee Payment Option with Both Laptop as well as Mobile.
    Not only Students but University Staff is also provided with many facilities on this platform.
    University itself can manage their all type of expenses on this platform in very easy and secured manner.
</p>
</div>
</section>




<section class="beni">
    <div class="container">
        <div class="f-flex">
            <div class="img-box">
                <div class="padding-box">
                    <img src="image/shield.png" alt="">
                </div>
                <h6>SECURED PAYMENT</h6>
            </div>
            <div class="img-box box22">
                <div class="padding-box">
                    <img src="image/email.png" alt="">
                </div>
                <h6>INTEGRATED <br>SMS ALERT</h6>
            </div>
            <div class="img-box box11">
                <div class="padding-box">
                    <img src="image/invoice.png" alt="">
                </div>
                <h6>AUTOMATIC <BR>RECEIPT GENERATE</h6>
            </div>
           
            <div class="img-box box33">
                <div class="padding-box">
                    <img src="image/user.png" alt="">
                </div>
                <h6>PROVIDES<BR>ADMIN LOGIN</h6>
            </div>
            <div class="img-box box44">
                <div class="padding-box">
                    <img src="image/credit-card.png" alt="">
                </div>
                <h6>CARD SCANNING<BR>FOR EXPENSE</h6>
            </div>
        </div>
    </div>
</section>




    </header>
    

    <?php
        include('footer.php');
        ?>
  


</body>
</html>