<?php

    $server = "127.0.0.1";
    $user = "root";
    $pass = "";
    $dbname = "payversity1";

    $conn = mysqli_connect($server, $user, $pass, $dbname);

    if(!$conn)
    {
        die("Connection failed!".mysqli_connect_error());
    }
    else
    {
        echo "";
    }
?>