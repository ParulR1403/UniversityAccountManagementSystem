<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Payversity</title>
    
    <link rel="stylesheet" href="css/style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <img src="image/logo_white.png" class="dashboard_logo" alt="">
      
    </div>
      <ul class="nav-links">
        <li  onclick="slide2()">
          <a href="dashboard.php" >
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li onclick="slide1()">
          <a href="New_student.php" >
            <i class='bx bx-list-ul' ></i>
            <!-- <i class='bx bx-box' ></i> -->
            <span class="links_name">Enter Student Data</span>
          </a>
        </li>
        <li>
          <a href="enrollment_search.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Enrollment Search</span>
          </a>
        </li>
        <li onclick="slide4()">
          <a href="detail_search.php" class="active">
            <i class='bx bx-list-ul' ></i>
            <!-- <i class='bx bx-pie-chart-alt-2' ></i> -->
            <span class="links_name">Detailed Search</span>
          </a>
        </li>
       
        <li>
          <a href="#">
            <i class='bx bx-cog' ></i>
            <span class="links_name">Settings</span>
          </a>
        </li>
        <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section" id="data2"> 
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
     
      <div class="profile-details">
        <img src="image/profile.jpg" alt="">
        <span class="admin_name">Prof. Prashant Sahatiya</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <div class="home-content detail_search">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
          <form class="form-other" action="" method="post" name="form">
           
                <label class="form-label-dept">Department : </label>
                    <select style="font-size: 16px;" class="department" name="department" id="department" onchange="sem(this.id,'semester')">
                        <option style="font-size: 15px;">Choose...</option>
                        <option value="Information Technology" style="font-size: 15px;">IT</option>
                        <option value="CSE" style="font-size: 15px;">CSE</option>
                        <option value="MECHANICAL" style="font-size: 15px;">MECHANICAL</option>
                        <option value="ELECTRICAL" style="font-size: 15px;">ELECTRICAL</option>
                        <option value="MCA" style="font-size: 15px;">MCA</option>
                        <option value="MBA" style="font-size: 15px;">MBA</option>
                        <option value="B.Sc" style="font-size: 15px;">B.Sc</option>
                    </select>
           

          
                <label class="form-label-sem">Semester :</label>
                    <select style="font-size: 16px;" class="semester" name="semester" id="semester">
                        <option>Choose...</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                    </select>
           

            
                <label class="form-label-status">Payment_Status :</label>
                <input type="radio" name="payment_status" value="Pending"><span>Pending</span>
                <input type="radio" name="payment_status" value="Succesfull"><span>Successfull</span>
            

            
                <label class="form-label-div">Divison :</label>
                    <select style="font-size: 16px;" class="divison" name="divison">
                        <option style="font-size: 15px;">Choose...</option>
                        <option value="A" style="font-size: 15px;">A</option>
                        <option value="B" style="font-size: 15px;">B</option>
                        <option value="C" style="font-size: 15px;">C</option>
                        <option value="D" style="font-size: 15px;">D</option>
                    </select>
            <br>
            <!--<a ng-click="checked = !checked" class="btn-signup">Sign Up</a>-->
            <div class="form-group">
                <button class="enroll-button" value="submit" name="submit" >Submit</button>
            </div>
		</form>
</div>
          <!-- <i class='bx bx-cart-alt cart'></i> -->
        </div>
        
      </div>
      <div class="sales-boxes">
        <div class="recent-sales box">
        <div class="title">Student Fees Detail</div>
          <div class="sales-details">
      <div class="row" id="example">
    <table class="table" id="table2excel">
          <thead>
            <tr class="data1">
                <th>Enrollment No.</th>
                <th>Name</th>
                <th>Department</th>
                <th>Semester</th>
                <th>Divison</th>
                <th>Payment_Status</th>      
            </tr>
        </thead>
      <?php

error_reporting(0);
include("db.php");
$filename="EmpData";
if(isset($_POST['submit']))
                    {

        $enrollment = $_POST['enrollment'];
        $department = $_POST['department'];
        $semester = $_POST['semester'];
        $divison = $_POST['divison'];
        $payment_status = $_POST['payment_status'];
            
            
        //checking about input whether all fields are filled or not
       
            
        if($department != "" && $payment_status != "" && $semester != "" && $divison != "")
        {
            $query = "SELECT * FROM payment WHERE enrollment = '$enrollment' OR department = '$department'  AND payment_status = '$payment_status' AND semester = '$semester' AND divison = '$divison' ";
                
                  
                $data = mysqli_query($conn, $query) or die('error');
                

                //fetching data
                if(mysqli_num_rows($data) > 0) 
                {
                     while($row = mysqli_fetch_assoc($data))
                     {
                         $enrollment = $row['enrollment'];
                         $name = $row['stud_name'];
                         $department = $row['department'];
                         $semester = $row['semester'];
                         $payment_status = $row['payment_status'];
                         $divison = $row['divison'];
                         

                    ?>
                 
        <tbody>
                     <tr class="data1">
                                        <td><?php echo $enrollment;?></td>
                                        <td><?php echo $name;?></td>
                                        <td><?php echo $department;?></td>
                                        <td><?php echo $semester;?></td>
                                        <td><?php echo $divison;?></td>
                                        <td><?php echo $payment_status;?></td>   
                                    </tr> 
                    
                     </div>
  
          
          </div>
          <?php
                                     }   
                                }    
                                else
                                {
                                    ?>
                                    <tr>
                                        
                                        <td>Records Not Found.......... Please Fill all Row</td>
                                    </tr>
                                    <?php
                                }
                            }
                        }
                            
                        
                    ?>
                     </tbody>
                     </table>
        <!--<div class="center">
            <button name="create_excel" value="create_excel" id="create_excel" class="btn-excel">  Excel file </button>
        </div>-->
        </div>
      
      </div>
    </div>
  </section>
  </body>
  <script src="./js/sem.js"></script>
  <script>
    $(function() {
    $("#create_excel").click(function(){
      $(".table").table2excel({
        exclude: ".xls",
        name: "Student_Data",
        filename : "Data_student"
          }); 
    });
  });
</script>
</html>