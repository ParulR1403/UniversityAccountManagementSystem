<?php
include("db.php");
session_start();
$enrollment = $_SESSION['enrollment'];

$mysqli = new mysqli("localhost","root","","payversity1");


$sql = "SELECT * FROM payment WHERE enrollment='$enrollment' ";
$result = $mysqli -> query($sql);

// Associative array
$row = $result -> fetch_assoc();
$stud_name = $row["stud_name"];
$course = $row["course"];
$department =$row["department"];
$divison = $row["divison"];
$semester = $row["semester"];
$amount = $row["amount"];
$amt = getIndianCurrency($amount);
$currentdate = date("d-m-Y");

function getIndianCurrency(float $number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'One', 2 => 'Two',
        3 => 'Three', 4 => 'Four', 5 => 'Five', 6 => 'Six',
        7 => 'Seven', 8 => 'Eight', 9 => 'Nine',
        10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve',
        13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen',
        16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
        19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty',
        40 => 'Forty', 50 => 'Fifty', 60 => 'Sixty',
        70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety');
    $digits = array('', 'Hundred','Thousand','Lakh', 'Crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
}

require('fpdf/fpdf.php');

class PDF extends FPDF
{
// Page header
function Header()
{
     // Logo
     $this->Image('pulogo.jpg',8,5,35);
      // Logo
    //   $this->Image('logo1.png',160,3,50);
    // Arial bold 15
    $this->SetFont('Arial','B',12);
    //Cell(width , height , text , border , end line , [align] )
    // Move to the right
    $this->Cell(77);
    // Title
    $this->Cell(0,1,'Parul University',0,1);
    $this->SetFont('Arial','B',8);
    // Move to the right
    $this->Cell(62);
    $this->Cell(0,7,'FACULTY OF ENGINEERING & TECHNOLOGY',0,1);
    // Move to the right
    $this->Cell(48);
    $this->Cell(0,1,'PARUL INSTITUTE OF ENGINEERING & TECHNOLOGY(FIRST SHIFT)',0,1);
    $this->SetFont('Arial','',8);
    $this->Cell(53);
    $this->Cell(0,7,'P.o.Limda, Tal. Waghodiya-391760, Dist. Vadodara, Gujarat(India)',0,1);
    $this->Cell(69);
    $this->Cell(0,1,'Ph. 02668-260300 Fax 02668-260300',0,1);
    $this->Cell(62);
    $this->Cell(0,7,'Email:piet@parul.ac.in Web:http://payversity.com',0,1);
    $this->SetFont('Arial','B',12);
    $this->Cell(0,7,'Fee Receipt',1,1,'C');
    // Line break
    $this->Ln(10);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','B',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
}
}

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);
$pdf->Cell(110,0,"Enrollment No.: $enrollment",0,0);
$pdf->Cell(20,0,"Course: $course",0,1);
$pdf->Cell(110,10,"Student Name: $stud_name",0,0);
$pdf->Cell(20,10,"Category : VACANT QUOTA",0,1);
$pdf->Cell(110,0,"Receipt No. : 01/18/0011560/F",0,0);
$pdf->Cell(20,0,"Fees Per Year : 4",0,1);
$pdf->Cell(110,10,"Department: $department",0,0);
$pdf->Cell(20,10,"Receipt Date : $currentdate",0,1);
$pdf->Cell(110,0,"Semester: $semester",0,0);
$pdf->Cell(20,0,"Divison : $divison",0,1);
$pdf->SetFont('Times','',10);
$pdf->Cell(20,10,"Received Fees as Per Following:",0,1);
$pdf->SetFont('Times','B',12);
$pdf->Cell(140,8,"P A R T I C U L A R",1,0,'C');
$pdf->Cell(50,8,"AMOUNT(Rs.)",1,1,'C');
$pdf->Cell(140,50,"Academic Fees",1,0);
$pdf->Cell(50,40,"$amount.00",1,1);
$pdf->Cell(140,10,"Total",1,0);
$pdf->Cell(50,10,"$amount.00 Rs.",1,1);
$pdf->Cell(20,10,"Amount In Words: $amt Only ",0,1);
$pdf->SetFont('Times','B',12);
$pdf->Cell(20,5,"Received By : PAYVERSITY",0,1);
$pdf->SetFont('Times','',10);
$pdf->Cell(20,7,"Under Schedule 1 articles 53 Exemption(B) of the India",0,1);
$pdf->Cell(20,0,"Stamp Act Charitable institutions are not required to",0,1);
$pdf->Cell(110,7,"issue Stamped receipt",0,0);
$pdf->SetFont('Times','',12);
$pdf->Cell(20,7,"For, PARUL INSTITUTE OF ENGG. & TECH",0,1);

// return;

$file = $enrollment.'_fee_receipt'.'.pdf';
$pdf->Output($file,'D');

?>