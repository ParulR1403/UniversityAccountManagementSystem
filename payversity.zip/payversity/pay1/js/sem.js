function sem(s1,s2)
            {
                var s1 = document.getElementById(s1);
                var s2 = document.getElementById(s2);

                s2.innerHTML = "";

                if(s1.value == "MCA" || s1.value == "MBA")
                {
                       var optionArray = ['1|1','2|2','3|3','4|4']; 
                }
                else if(s1.value == "Information Technology" || s1.value == "CSE" || s1.value == "ELECTRICAL" || s1.value == "MECHANICAL")
                {
                    var optionArray = ['1|1','2|2','3|3','4|4','5|5','6|6','7|7','8|8'];
                }
                else if(s1.value == "B.Sc")
                {
                    var optionArray = ['1|1','2|2','3|3','4|4','5|5','6|6'];
                }

                for(var option in optionArray)
                {
                    var pair = optionArray[option].split("|");
                    var newoption = document.createElement("option");

                    newoption.value = pair[0];
                    newoption.innerHTML = pair[1];
                    s2.options.add(newoption);
                }
            }