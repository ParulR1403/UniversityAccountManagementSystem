$(function() {
	$(".btn").click(function() {
		$(".form-enrollment").toggleClass("form-enrollment-left");
    $(".form-other").toggleClass("form-other-left");
    $(".frame").toggleClass("frame-long");
    $(".other-inactive").toggleClass("other-active");
    $(".enrollment-inactive").toggleClass("enrollment-active");
    $(".forgot").toggleClass("forgot-left");   
    $(this).removeClass("idle").addClass("active");
	});
});


