$(function() {
    $("#create_excel").click(function(){
      $(".table").table2excel({
        exclude: ".xls",
        name: "Student_Data",
        filename : "Data_student"
          }); 
    });
  });