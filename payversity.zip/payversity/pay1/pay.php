<?php
session_start();
$enrollment = $_SESSION['enrollment'];
$amount = intVal($_POST['main_select']) ;
echo $enrollment; 
echo $amount;
?>
  <link rel='stylesheet' type='text/css' media='screen' href='css/style.css'>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<div class="container pay-1">
            <div class="row justify-content-center login-banner pay-2">
                <div class="col-lg-5 bg-grey mt-9 px-0"> <!--main part-->
                <div class="login-main">
                <img src="image/logo_new.png" alt="" class="login-logo">
                </div>
                    <h3 class="text-center p-1 rounded-top login-main2">Payer's Detail</h3> 
                    <form action="#" method="POST" class="p-4">
                         <label for="user">Enter Payer's Name</label>
                         <div class="form-group bg-red-lg">
                             <input type="textbox" name="pname" id="pname" class="form-control form-control-lg"  >
                         </div>
                         <label for="user">Enter Payer's contact No.</label>
                         <div class="form-group bg-red-lg">
                              
                             <input type="textbox" name="pcont" id="pcont" class="form-control form-control-lg "  >
                         </div>
                         <label for="user">Enter Payers's Email</label>
                         <div class="form-group bg-red-lg">
                              
                             <input type="email" name="pemail" id="pemail" class="form-control form-control-lg "  >
                         </div>
                        

                        <!--
                         <div class="form-group">
                             <input type="submit" name="login" class="btn btn-danger btn-block mt-3 p-2"/>       
                         </div>
                         -->
                         <div class="form-group ">
                            <input type="button" name="btn" id="btn" value="Pay Now"  class=" login-page btn btn-danger btn-block mt-3 p-2" onclick="pay_now()"/>
                         </div>
                         </div>
            </div>
        </div>
                         

                     </form>

<script>
var amt = '<?=$amount?>';
var enrollment= '<?=$enrollment?>';
    function pay_now(){
        var pname=jQuery('#pname').val();
        var pcont=jQuery('#pcont').val();
        var pemail=jQuery('#pemail').val();
        
         jQuery.ajax({
               type:'post',
               url:'payment_process.php',
               data:"amt="+amt+"&pname="+pname+"&enrollment="+enrollment+"&pcont="+pcont+"&pemail="+pemail,
               success:function(result){
                   var options = {
                        "key": "rzp_test_2QsJTaMrnjeOTQ", 
                        "amount": amt*100, 
                        "currency": "INR",
                        "name": "PayVersity",
                        "description": "Test Transaction",
                        "image": "logo1.png",
                        "handler": function (response){
                           jQuery.ajax({
                               type:'post',
                               url:'payment_process.php',
                               data:"payment_id="+response.razorpay_payment_id,
                               success:function(result){
                                   window.location.href="thank_you.php";
                               }
                           });
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.open();
               }
           });
        
        
    }
</script>
