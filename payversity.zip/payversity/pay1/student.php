<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayVersity</title>
    <link rel='stylesheet' type='text/css' media='screen' href='css/style.css'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>
<body>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">

                <div class="card mt-5">
                    <div class="card-header text-center">
                        <h4>View Fees Details</h4>
                    </div>
                    <div class="card-body">

                        <form action="view.php" method="GET">
                            <div class="row">
                                <div class="col-md-8">
                                    <label for="">Enter Your Enrollment No. </label>
                                    <input type="text" name="enrollment" value="<?php if(isset($_GET['enrollment'])){echo $_GET['enrollment'];} ?>" class="form-control">
                                </div>
                                <div class="col-md-4 mt-4">
                                    <button type="submit" name="submit" class="btn btn-primary" value="redirect" >View Details</button>
                                </div>
                            </div>
                        </form>

                        <div class="row">
                            <div class="col-md-12">
                                <hr>
                                <?php 
                                    include("db.php");
                                    //$conn = mysqli_connect("localhost","root","","payversity1");

                                    if(isset($_GET['enrollment']))
                                    {
                                        $stud_id = $_GET['enrollment'];

                                        $query = "SELECT * FROM payment WHERE enrollment='$enrollment' ";
                                        $query_run = mysqli_query($conn, $query);

                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            header("Location: http://localhost/dash/view.php");
                                            exit();                                          
                                        }
                                        else
                                        {
                                            echo "No Record Found!";
                                        }
                                    }
                                   
                                ?>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
  
</body>
</html>