<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payversity</title>
    <link rel='stylesheet' type='text/css' media='screen' href='css/style.css'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
       <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">

                <div class="card mt-5">
                    <div class="card-header text-center">
                        <h4>View Your Details</h4>
                    </div>
                    <div class="card-body">                      
                                <?php 
                                    session_start();
                                    $conn = mysqli_connect("localhost","root","","payversity1");

                                    if(isset($_GET['enrollment']))
                                    {
                                        $enrollment = $_GET['enrollment'];
                                        $_SESSION['enrollment']=$enrollment;
                                        
                                        $query = "SELECT * FROM payment WHERE enrollment='$enrollment' ";
                                        $query_run = mysqli_query($conn, $query);
                                       
                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $row)
                                            {
                                                ?>
                                                <div class="form-group mb-3">
                                                    <label for="">Name</label>
                                                    <input type="text" value="<?= $row['stud_name']; ?>" class="form-control">
                                                </div>
                             
                                                <div class="form-group mb-3">
                                                    <label for="">Enrollment No.</label>
                                                    <input type="text"name="enrollment" value="<?= $row['enrollment']; ?>" class="form-control">
                                                </div>       
                                                                                     
                                                <div class="form-group mb-3">
                                                    <label for="">Course</label>
                                                    <input type="text" value="<?= $row['course']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Department</label>
                                                    <input type="text" value="<?= $row['department']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Semester</label>
                                                    <input type="text" value="<?= $row['semester']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Divison</label>
                                                    <input type="text" value="<?= $row['divison']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Start Date</label>
                                                    <input type="text" value="<?= $row['start_date']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Due Date</label>
                                                    <input type="text" value="<?= $row['due_date']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Payment Status</label>
                                                    <input type="text" value="<?= $row['payment_status']; ?>" name="payment_status" class="form-control">
                                                    <?php 
                                                        $ps= $row['payment_status'];
                                                        $s="Pending";
                                                                
                                                                if($ps==$s){
                                                                ?>
                                                                    <div>
                                                                        <form id="main_form" name="main_form" method="post" action="pay.php">
                                                                        <select id="main_select" name="main_select">
                                                                        <option value="" disabled selected>Select Fee</option>
                                                                        <option value="45000">Semester Fees</option>
                                                                        <option value="90000">Yearly Fees</option>                                        
                                                                        </select>
                                                                        <br/></br></br></br>
                                                                        <center>
                                                                        <input type="submit" id="main_submit" class="btn btn-primary" name="main_submit" value="Pay Now" />
                                                                        </center>
                                                                        </form>
                                                                    </div>
                                                                <?php
                                                                }
                                                                else {
                                                                ?>
                                                                 <div>  
                                                                        <?php   
                                                                        $_SESSION['enrollment']=$enrollment;                                                                        
                                                                        ?>
                                                                        <form id="pdf_form" name="pdf_form" method="post" action="pdf_generation.php">
                                                                        </br>                                                                       
                                                                        <center>
                                                                        <input type="submit" id="pdf_download" class="btn btn-primary" name="pdf_download" value="Download" />
                                                                        </center>
                                                                        </form>
                                                                    </div>
                                                                <?php
                                                                }
                                                        ?>

                                                </div>                                               
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            echo "No Record Found!";
                                        }
                                    }
                                   
                                ?>

                            </div>
                  
                </div>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>