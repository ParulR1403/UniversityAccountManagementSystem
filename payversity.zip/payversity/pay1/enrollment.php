
          <?php
//var_dump($_POST['enroll']);
//return;

              error_reporting(0);
              include("db.php");
              
              $filename="EmpData";


/*  
              if(isset($_POST['enroll']))
                  {*/
                       $enrollment = $_POST['enroll'];

                     
                      $department = $_POST['department'];
                      $semester = $_POST['semester'];
                      $divison = $_POST['divison'];
                      $payment_status = $_POST['payment_status'];
                          
                          
                      //checking about input whether all fields are filled or not
                      /*if($enrollment != "" || ($department != "" && $payment_status != "" && $semester != "" && $divison != ""))
                          {*/
                              $query = "SELECT * FROM payment WHERE enrollment = '$enrollment' OR department = '$department'  AND payment_status = '$payment_status' AND semester = '$semester' AND divison = '$divison' ";
                              $data = mysqli_query($conn, $query) or die('error');
                              
                              //fetching data
                              if(mysqli_num_rows($data) > 0) 
                              {
                               $row = mysqli_fetch_all($data,MYSQLI_ASSOC);
                                  // var_dump($row); 

                                   $value['id'] = $row[0]['enrollment'];
                                   $value['student_name'] = $row[0]['stud_name'];
                                   $value['dept'] = $row[0]['department'];
                                   $value['sem'] = $row[0]['semester'];
                                   $value['pay_status'] = $row[0]['payment_status'];
                                   $value['div'] = $row[0]['divison'];
                                   /*while($row = mysqli_fetch_assoc($data))
                                   {
                                       $value['id'] = $row['enrollment'];
                                       $value['name'] = $row['stud_name'];
                                       $department = $row['department'];
                                       $semester = $row['semester'];
                                       $payment_status = $row['payment_status'];
                                       $divison = $row['divison']; 
                               
                                    }*/
                                    echo json_encode($value);
                                    return;    
                                  
                              }    
                              else
                              {
                                  ?>
                                  <!-- <tr>
                                      
                                      <td>Records Not Found.......... Please Fill all Row</td>
                                  </tr> -->
                                  <?php
                              }
                          /*}*/
                      /*}*/
                  ?>
    
    