<?php
session_start();
include("db.php");
if(isset($_POST['amt']) && isset($_POST['pname']) && isset($_POST['pcont']) && isset($_POST['pemail']) && isset($_POST['enrollment'])){
    $amt=$_POST['amt'];
    $pname=$_POST['pname'];
    $pcont=$_POST['pcont'];
    $pemail=$_POST['pemail'];
    $enrollment=$_POST['enrollment'];
    $payment_status="Pending";
    $time=date('Y-m-d h:i:s');
    mysqli_query($conn,"update payment set pname='$pname',pcont='$pcont',pemail='$pemail',amount='$amt',payment_status='$payment_status',time='$time' where enrollment='$enrollment'");
    $_SESSION['OID']=$enrollment;
}

if(isset($_POST['payment_id']) && isset($_SESSION['OID'])){
    $payment_id=$_POST['payment_id'];
    mysqli_query($conn,"update payment set payment_status='succesfull',payment_id='$payment_id' where enrollment='".$_SESSION['OID']."'");

}




   

?>