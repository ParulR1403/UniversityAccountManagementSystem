<!DOCTYPE html>
<html>
<head>

    <title>Faculty Panel</title>
    <meta charset="UTF-8">
    

    <link rel="stylesheet" href="./css/faculty_style.css">
</head>
<body>

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
<a href="logout.php"><button class="login">Logout</button></a>
<div class="container">
  <div class="frame">
    <div class="nav">
      <ul class="links">
        <li class="enrollment-active"><a class="btn">By Enrollment No. </a></li>
        <li class="other-inactive"><a class="btn">By Others </a></li>
      </ul>
    </div>

    <div ng-app ng-init="checked = false">
		<form class="form-enrollment" action="" method="post" name="form">
            <label  for="enrollment">enrollment no </label>
            <input class="form-styling" type="text" name="enrollment" placeholder="" />
            <div class="form-group">
                <button class="btn-submit" value="submit" name="submit" >Submit</button>
               
            </div>
		</form>
        
        
        <form class="form-other" action="" method="post" name="form">
            <div class="form-group">
                <label class="form-label-dept">Department : </label>
                    <select style="font-size: 18px;" class="department" name="department" id="department" onchange="sem(this.id,'semester')">
                        <option style="font-size: 15px;">Choose...</option>
                        <option value="Information Technology" style="font-size: 15px;">IT</option>
                        <option value="CSE" style="font-size: 15px;">CSE</option>
                        <option value="MECHANICAL" style="font-size: 15px;">MECHANICAL</option>
                        <option value="ELECTRICAL" style="font-size: 15px;">ELECTRICAL</option>
                        <option value="MCA" style="font-size: 15px;">MCA</option>
                        <option value="MBA" style="font-size: 15px;">MBA</option>
                        <option value="B.Sc" style="font-size: 15px;">B.Sc</option>
                    </select>
            </div><br>

            <div class="form-group">
                <label class="form-label-sem">Semester :</label>
                    <select class="semester" name="semester" id="semester">
                        <option>Choose...</option>
                        <!--<option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>-->
                    </select>
            </div><br>

            <div class="form-group">
                <label class="form-label-status">Payment_Status :</label>
                <input type="radio" name="payment_status" value="Pending"><span>Pending</span>
                <input type="radio" name="payment_status" value="Succesfull"><span>Successfull</span>
            </div><br>

            <div class="form-group">
                <label class="form-label-div">Divison :</label>
                    <select class="divison" name="divison">
                        <option style="font-size: 15px;">Choose...</option>
                        <option value="A" style="font-size: 15px;">A</option>
                        <option value="B" style="font-size: 15px;">B</option>
                        <option value="C" style="font-size: 15px;">C</option>
                        <option value="D" style="font-size: 15px;">D</option>
                    </select>
            </div><br>
            <!--<a ng-click="checked = !checked" class="btn-signup">Sign Up</a>-->
            <div class="form-group">
                <button class="btn-submit" value="submit" name="submit" >Submit</button>
            </div>
		</form>
      </div>
  </div>
</div>

<div class="row" id="example">
    <table class="table" id="table2excel">
        <thead>
            <tr>
                <th>Enrollment No.</th>
                <th>Name</th>
                <th>Department</th>
                <th>Semester</th>
                <th>Divison</th>
                <th>Payment_Status</th>      
            </tr>
        </thead>
                
        <tbody>
            <?php

                error_reporting(0);
                include("db.php");
                $filename="EmpData";
                if(isset($_POST['submit']))
                    {
                        $enrollment = $_POST['enrollment'];
                       
                        $department = $_POST['department'];
                        $semester = $_POST['semester'];
                        $divison = $_POST['divison'];
                        $payment_status = $_POST['payment_status'];
                            
                            
                        //checking about input whether all fields are filled or not
                        if($enrollment != "" || ($department != "" && $payment_status != "" && $semester != "" && $divison != ""))
                            {
                                $query = "SELECT * FROM payment WHERE enrollment = '$enrollment' OR department = '$department'  AND payment_status = '$payment_status' AND semester = '$semester' AND divison = '$divison' ";
                                
                                  
                                $data = mysqli_query($conn, $query) or die('error');
                                

                                //fetching data
                                if(mysqli_num_rows($data) > 0) 
                                {
                                     while($row = mysqli_fetch_assoc($data))
                                     {
                                         $enrollment = $row['enrollment'];
                                         $name = $row['stud_name'];
                                         $department = $row['department'];
                                         $semester = $row['semester'];
                                         $payment_status = $row['payment_status'];
                                         $divison = $row['divison'];
                                         
                                    ?>
                                     <tr>
                                        <td><?php echo $enrollment;?></td>
                                        <td><?php echo $name;?></td>
                                        <td><?php echo $department;?></td>
                                        <td><?php echo $semester;?></td>
                                        <td><?php echo $divison;?></td>
                                        <td><?php echo $payment_status;?></td>   
                                    </tr> 
                                    <?php
                                     }   
                                }    
                                else
                                {
                                    ?>
                                    <tr>
                                        
                                        <td>Records Not Found.......... Please Fill all Row</td>
                                    </tr>
                                    <?php
                                }
                            }
                        }
                    ?>
        </tbody>
    </table>
        <!--div class="center">
            <button name="create_excel" value="create_excel" id="create_excel" class="btn-excel">  Excel file </button>
        </div>-->
    </div>
</div>
        
<!-- Scripts -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="./js/sem.js"></script>
<script src="./js/script.js"></script>
<!--<script>
    $(function() {
    $("#create_excel").click(function(){
      $(".table").table2excel({
        exclude: ".xls",
        name: "Student_Data",
        filename : "Data_student"
          }); 
    });
  });
</script>-->

</body>
</html>