<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Property Porium-Home</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src='script.js'></script>
   
</head>
<body>   

    <footer>
        <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <h3>ABOUT COMPANY</h3>
                <p> totam sunt, repudiandae, quia aliquam nulla velit sed amet quasi voluptatum. velit sed amet quasi voluptatum.</P>
            </div>
            <div class="col-lg-3">
                <h3>USEFUL LINK</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="work.php">How Its Works</a></li>
                    <li><a href="benefits.php">Benefits to Investors</a></li>
                    <li><a href="faqs.php">FAQs.</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h3>CONTACT</h3>
                <p> totam sunt, repudiandae, quia aliquam nulla velit sed amet quasi voluptatum. velit sed amet quasi voluptatum.</P>
                <h6>Email : giulietv@gmail.com</h6>
                <h6>Number : +91 - 1234567890</h6>
                <div class="icon">
                    <span class="fa fa-facebook"></span>
                    <span class="fa fa-instagram"></span>
                    <span class="fa fa-twitter"></span>
                </div>
            </div>
            <div class="col-lg-3">
                <h3>SIGN UP</h3>
                <form action="">
                    <input type="email" placeholder="Enter Your Email">
                    <button class="btn-up">SIGN UP</button>
                </form>
            </div>
        </div>
        </div>
    </footer>


<section>
    <div class="copy-right">
        <p>Copyright ©2021-22 All rights reserved by Property Porium | This Website Made by <a href="">  <span>PAYVERSITY</span></a></p>
    </div>
</section>
        </body>
</html>