<Center><h1>Payment Successful!</h1></center>
<!-- 180303108123@paruluniversity.ac.in -->
<?php
    //include_once 'connection/config.php';

    // Import PHPMailer classes into the global namespace
    // These must be at the top of your script, not inside a function
    session_start();
    $enrollment = $_SESSION['enrollment'];
//     var_dump($enrollment);
      $conn = mysqli_connect("localhost","root","","payversity1");

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    // Load Composer's autoloader
    require 'vendor/autoload.php';

    $query = "SELECT * FROM `payment` WHERE `enrollment`= '$enrollment'"; 
    
        
    $result = mysqli_query($conn,$query) or die(mysqli_error());
    
    
    while($row = mysqli_fetch_array($result)){
                
                $email = $row['pemail'];

                
                $mail = new PHPMailer(true);
            
            
                      try {
                          
                            $mail->isSMTP();                                            
                            $mail->Host       = "smtp.gmail.com";                
                            $mail->SMTPAuth   = true;                                   
                            $mail->Username   = 'payversity@gmail.com';               // SMTP username
                            $mail->Password   = 'RPSY@123';                     // SMTP password
                            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
                            $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
        
                            //Recipients
                            $mail->setFrom('payversity@gmail.com', 'Payversity');
                            $mail->addAddress($email, 'User');     
                           
                            $mail->isHTML(true);                   
                           
                            $mail->Subject = 'Test Mail';
                            $mail->Body    = "Test Mail";
                            $file_to_attach = "180303108123.pdf";

                            $mail->AddAttachment( $file_to_attach , '180303108123.pdf' );
                                
                            $mail->send();
                              $response["status"] = 1;
                              $response["message"] = "mail Send Suceessfully";
                              die(json_encode($response));
                        } catch (Exception $e) {
                              echo "Mailer Error: " . $mail->ErrorInfo;
                          
                              $response["status"] = 0;
                              $response["message"] = "Problem to sending Email ";
                              die(json_encode($response));
                        }
                       }
                    
    //}

?>