<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Payversity</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="js/sem.js">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <img src="image/logo_white.png" class="dashboard_logo" alt="">
    </div>

    <ul class="nav-links">
      <li  onclick="slide2()">
        <a href="#" class="active">
          <i class='bx bx-grid-alt' ></i>
          <span class="links_name">Dashboard</span>
        </a>
      </li>
      <li onclick="slide1()">
        <a href="New_student.php" >
          <i class='bx bx-list-ul' ></i>
          <!-- <i class='bx bx-box' ></i> -->
          <span class="links_name">Enter Student Data</span>
        </a>
      </li>
      <li onclick="slide3()">
        <a href="enrollment_search.php" >
          <i class='bx bx-list-ul' ></i>
          <span class="links_name">Enrollment Search</span>
        </a>
      </li>
        <li onclick="slide4()">
          <a href="detail_search.php">
            <i class='bx bx-list-ul' ></i>
            <!-- <i class='bx bx-pie-chart-alt-2' ></i> -->
            <span class="links_name">Detailed Search</span>
          </a>
        </li>
       
        <li>
          <a href="#">
            <i class='bx bx-cog' ></i>
            <span class="links_name">Settings</span>
          </a>
        </li>
        <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section" id="data2"> 
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
     
      <div class="profile-details">
        <img src="image/profile.jpg" alt="">
        <span class="admin_name">Prof. Prashant Sahatiya      
        </span>
        <!--<i class='bx bx-chevron-down' ></i>-->
      </div>
    </nav>
   

   










    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">No. of Total Students</div>
            <div class="number"><!--40,000-->
                <?php
                  include("db.php");

                  $query = 'SELECT enrollment FROM payment ORDER BY enrollment';
                  $query_run = mysqli_query($conn, $query) or die('error');
                   
                  $row = mysqli_num_rows($query_run);

                  echo '<h3>'.$row.'</h3>'
                ?>
            </div>
           
          </div>
          <!-- <i class='bx bx-cart-alt cart'></i> -->
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">No. of Paid Students</div>
            <div class="number"><!--30,000-->
            <?php
                  include("db.php");

                  $query = "SELECT enrollment FROM payment WHERE payment_status = 'succesfull' ";
                  $query_run = mysqli_query($conn, $query) or die('error');
                   
                  $row = mysqli_num_rows($query_run);

                  echo '<h3>'.$row.'</h3>'
                ?>

            </div>
           
          </div>
          <!-- <i class='bx bxs-cart-add cart two' ></i> -->
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">No. of Unpaid Students</div>
            <div class="number"><!--10,000-->

            <?php
                  include("db.php");

                  $query = "SELECT enrollment FROM payment WHERE payment_status = 'Pending' ";
                  $query_run = mysqli_query($conn, $query) or die('error');
                   
                  $row = mysqli_num_rows($query_run);

                  echo '<h3>'.$row.'</h3>'
                ?>

            </div>
          
          </div>
          <!-- <i class='bx bx-cart cart three' ></i> -->
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">No. of Penalty Students</div>
            <div class="number">5,000</div>
          </div>
       </div>
      </div>
      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="export">
            <DIV>
        <div class="title ">Student Fees Detail</div>
        </DIV>
        <div>
        
     <div class="export-left-mr">
       <a href="export.php" class="export-link">
         <button class="export-btn">Export</button></a>
     

     </div>
     </div>
     </div>
  



          <div class="sales-details">
      <div class="row" id="example">
    <table class="table" id="table2excel">
          <thead>
            <tr>
                <th>Enrollment No.</th>
                <th>Name</th>
                <th>Department</th>
                <th>Semester</th>
                <th>Divison</th>
                <th>Payment_Status</th>      
            </tr>
        </thead>
      <?php

error_reporting(0);
include("db.php");

$filename="EmpData";

        $enrollment = $_POST['enrollment'];
       
        $department = $_POST['department'];
        $semester = $_POST['semester'];
        $divison = $_POST['divison'];
        $payment_status = $_POST['payment_status'];
            
            
        //checking about input whether all fields are filled or not
       
            
                $query = "SELECT * FROM payment";
                
                  
                $data = mysqli_query($conn, $query) or die('error');
                

                //fetching data
                if(mysqli_num_rows($data) > 0) 
                {
                     while($row = mysqli_fetch_assoc($data))
                     {
                         $enrollment = $row['enrollment'];
                         $name = $row['stud_name'];
                         $department = $row['department'];
                         $semester = $row['semester'];
                         $payment_status = $row['payment_status'];
                         $divison = $row['divison'];
                         

                    ?>
                 
        <tbody>
                     <tr class="data1">
                                        <td><?php echo $enrollment;?></td>
                                        <td><?php echo $name;?></td>
                                        <td><?php echo $department;?></td>
                                        <td><?php echo $semester;?></td>
                                        <td><?php echo $divison;?></td>
                                        <td><?php echo $payment_status;?></td>   
                                    </tr> 
                    
                     </div>
  
          
          </div>
          <?php
                                     }   
                                }    
                                else
                                {
                                    ?>
                                    <tr>
                                        
                                        <td>Records Not Found.......... Please Fill all Row</td>
                                    </tr>
                                    <?php
                                }
                            
                        
                    ?>
                     </tbody>
                     
                     </table>
        </div>
        
      </div>
    </div>
  </section>
  </section>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
  
  jQuery(document).ready(function(){
    $('#submit').click(function(e) {
      e.preventDefault();
 

        var search = jQuery('#search').val();
         

              
              jQuery.ajax({
                  url :'http://localhost:8080/Project/dash/dash/enrollment.php' , 
                  type : 'POST',
                  data : {enroll:search},
                  datatype: "JSON",
                  success: function(response) {
                      
                      
                      var value = jQuery.parseJSON(response);
                      console.log(value);

                     if(data.status == false){
                          jQuery("#table-data").append("<tr><td colspan='3'><h1>"+ data.message +"</h1></td></tr>");
                      }else{
                          
                              
                              jQuery("#table-data").append("<tr>" +
                                                          "<td>" + value.id +"</td>" +
                                                          "<td>" + value.student_name +"</td>" +
                                                          "<td>" + value.dept +"</td>" +
                                                          "<td>" + value.sem +"</td>" +
                                                          
                                                          "<td>" + value.div +"</td>" +
                                                          "<td>" + value.pay_status +"</td>" +
                                                         

                                                          "</tr>");
                            
                      }
                  }
              });
          


    });
});
</script>
<script>
  
  jQuery(document).ready(function(){
    $('#submit1').click(function(e) {
      e.preventDefault();
 

        // var search = jQuery('#search').val();
        // var search_sem = jQuery('#search-sem').val();
        // var search_div = jQuery('#search_div').val();
        // var search_status = jQuery('#search_status').val();

         

              
        //       jQuery.ajax({
        //           url :'http://localhost:8080/Project/dash/dash/enrollment.php' , 
        //           type : 'POST',
        //           data : {department:search,semester:search_sem,divison:search_div,payment_status:search_status},
        //           datatype: "JSON",
        //           success: function(response) {
                      
                      
        //               var value = jQuery.parseJSON(response);
        //               console.log(value);

        //              if(data.status == false){
        //                   jQuery("#table-data").append("<tr><td colspan='3'><h1>"+ data.message +"</h1></td></tr>");
        //               }else{
                          
                              
        //                       jQuery("#table-data").append("<tr>" +
        //                                                   "<td>" + value.id +"</td>" +
        //                                                   "<td>" + value.student_name +"</td>" +
        //                                                   "<td>" + value.dept +"</td>" +
        //                                                   "<td>" + value.sem +"</td>" +
                                                          
        //                                                   "<td>" + value.div +"</td>" +
        //                                                   "<td>" + value.pay_status +"</td>" +
                                                         

        //                                                   "</tr>");
                            
        //               }
        //           }
              });
          


    });
// });
</script>

   <!--<div class="row" id="example">
    <table class="table" id="table-data">
        <thead>
            <tr>
                <th>Enrollment No.</th>
                <th>Name</th>
                <th>Department</th>
                <th>Semester</th>
                <th>Divison</th>
                <th>Payment_Status</th>      
            </tr>
        </thead>
                
       
    </table>
    </div>
</div>
   </section>-->

   

  <script>
 function slide1() {
  var x = document.getElementById("data1");
  var y = document.getElementById("data2");
  var z = document.getElementById("data3");
  var u = document.getElementById("data4");

  x.style.display = "block";
  y.style.display = "none";
  z.style.display = "none";
  u.style.display = "none";
 
}

function slide2() {
  var x = document.getElementById("data1");
  var y = document.getElementById("data2");
  var z = document.getElementById("data3");
  var u = document.getElementById("data4");

  y.style.display = "block";
  x.style.display = "none";
  z.style.display = "none";
  u.style.display = "none";
 
}

function slide3() {
  var x = document.getElementById("data1");
  var y = document.getElementById("data2");
  var z = document.getElementById("data3");
  var u = document.getElementById("data4");

  
  y.style.display = "none";
  x.style.display = "none";
  z.style.display = "block";
  u.style.display = "none";
}
function slide4() {
  var x = document.getElementById("data1");
  var y = document.getElementById("data2");
  var z = document.getElementById("data3");
  var u = document.getElementById("data4");

  
  y.style.display = "none";
  x.style.display = "none";
  z.style.display = "none";
  u.style.display = "block";
 
}

   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>
 
<script src="./js/script.js"></script>

</body>
</html>
