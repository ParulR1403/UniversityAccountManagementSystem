<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Payversity</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <img src="image/logo_white.png" class="dashboard_logo" alt="">
      
    </div>
      <ul class="nav-links">
        <li  onclick="slide2()">
          <a href="dashboard.php" >
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li onclick="slide1()">
          <a href="New_student.php" >
            <i class='bx bx-list-ul' ></i>
            <!-- <i class='bx bx-box' ></i> -->
            <span class="links_name">Enter Student Data</span>
          </a>
        </li>
        <li>
          <a href="enrollment_search.php" class="active">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Enrollment Search</span>
          </a>
        </li>
        <li onclick="slide4()">
          <a href="detail_search.php">
            <i class='bx bx-list-ul' ></i>
            <!-- <i class='bx bx-pie-chart-alt-2' ></i> -->
            <span class="links_name">Detailed Search</span>
          </a>
        </li>
       
        <li>
          <a href="#">
            <i class='bx bx-cog' ></i>
            <span class="links_name">Settings</span>
          </a>
        </li>
        <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section" id="data2"> 
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
     
      <div class="profile-details">
        <img src="image/profile.jpg" alt="">
        <span class="admin_name">Prof. Prashant Sahatiya</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <div class="home-content enrollment">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
          <form class="form-enrollment" id="data" action="" method="post" name="form">
      <label  for="enrollment">Enrollment No: </label>
      <input class="form-styling" id="search" type="text" name="enrollment" placeholder="" />
    
          <button class="enroll-button" id="submit" type="submit" value="submit" name="submit" >Search</button>
         
   
</form>
</div>
          <!-- <i class='bx bx-cart-alt cart'></i> -->
        </div>
        
      </div>
      <div class="sales-boxes">
        <div class="recent-sales box">
        <div class="title">Student Fees Detail</div>
          <div class="sales-details">
      <div class="row" id="example">
    <table class="table" id="table2excel">
                      <thead>
            <tr class="data1">
                <th>Enrollment No.</th>
                <th>Name</th>
                <th>Department</th>
                <th>Semester</th>
                <th>Divison</th>
                <th>Payment_Status</th>      
            </tr>
        </thead>
      <?php

error_reporting(0);
include("db.php");
$filename="EmpData";
if(isset($_POST['submit']))
                    {

        $enrollment = $_POST['enrollment'];
       
        $department = $_POST['department'];
        $semester = $_POST['semester'];
        $divison = $_POST['divison'];
        $payment_status = $_POST['payment_status'];
            
            
        //checking about input whether all fields are filled or not
       
            
        if($enrollment != "")
        {
            $query = "SELECT * FROM payment WHERE enrollment = '$enrollment'";
                
                  
                $data = mysqli_query($conn, $query) or die('error');
                

                //fetching data
                if(mysqli_num_rows($data) > 0) 
                {
                     while($row = mysqli_fetch_assoc($data))
                     {
                         $enrollment = $row['enrollment'];
                         $name = $row['stud_name'];
                         $department = $row['department'];
                         $semester = $row['semester'];
                         $payment_status = $row['payment_status'];
                         $divison = $row['divison'];
                         

                    ?>
                 
        <tbody>
                     <tr class="data1">
                                        <td><?php echo $enrollment;?></td>
                                        <td><?php echo $name;?></td>
                                        <td><?php echo $department;?></td>
                                        <td><?php echo $semester;?></td>
                                        <td><?php echo $divison;?></td>
                                        <td><?php echo $payment_status;?></td>   
                                    </tr> 
                    
                     </div>
  
          
          </div>
          <?php
                                     }   
                                }    
                                else
                                {
                                    ?>
                                    <tr>
                                        
                                        <td>Records Not Found.......... Please Fill all Row</td>
                                    </tr>
                                    <?php
                                }
                            }
                        }
                            
                        
                    ?>
                     </tbody>
                     </table>
          <!-- <div class="button">
            <a href="logout.php">Logout</a>
          </div> -->
        </div>
      
      </div>
    </div>
  </section>
  </body>
</html>